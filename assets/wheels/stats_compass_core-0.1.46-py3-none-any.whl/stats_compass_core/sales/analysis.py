"""The series statistics on one group's sales, with the Shopify app's settings.

The calibration is the app's (hosted's commerce engine): the Fourier
decomposition, an expected band at 2 standard deviations, a noise band at 2.5,
a 5% test, 90% intervals, a four-week baseline before a promotion, three
weeks after it left out of the fit. Weekly input uses the same settings in
whole weeks.
"""

from __future__ import annotations

import math
import re
from datetime import date, timedelta
from typing import Any, Literal

import pandas as pd
from pydantic import BaseModel, Field

from stats_compass_core.sales import wording
from stats_compass_core.sales.schema import (
    SERIES_KIND,
    Freq,
    GroupSeries,
    PromotionWindow,
)
from stats_compass_core.series import (
    Insufficient,
    decompose,
    its_lift,
    month_effects,
    verdict,
)
from stats_compass_core.series._common import WeekLabel, week_days, weekly_freq, weeks_overlapping

METHOD = "fourier"
DAILY_PERIODS = (7, 365)
CAL = {"seasonal_band_z": 2.0, "noise_band_z": 2.5, "real_change_alpha": 0.05}
LEVEL = 0.9
# The longest run of missing rows filled in: a week of days, or two weeks.
MAX_GAP_DAYS = {"D": 7, "W": 14}
BASELINE_DAYS = 28
BASELINE_LOOKBACK_DAYS = 84
POST_DAYS = 21
SERIES_DAYS_BEFORE = 28
SERIES_DAYS_AFTER = 21
# A run of this many days or more with no sales, in a store that sells on most
# days, is a closure: those days are left out as missing, not read as zero sales.
CLOSURE_MIN_DAYS = 3
# Under two years of history before a promotion, its season is read from one earlier year.
ONE_YEAR_HISTORY_DAYS = 730
# A promotion starting this soon after a closure can carry orders held over from it
# (on UCI Online Retail II, the first week after the Christmas closure did, both years).
REOPENING_DAYS = 14
# The fewest clear days before the next promotion for the weeks after one to be judged.
MIN_AFTER_DAYS = 7

Outcome = Literal["expected", "noise", "real change", "insufficient"]
ORDER = {"real change": 0, "noise": 1, "expected": 2, "insufficient": 3}


def _decompose_options(freq: Freq, week_label: WeekLabel) -> dict[str, Any]:
    if freq == "W":
        return {"method": METHOD, "freq": "W", "week_label": week_label, "max_gap_days": MAX_GAP_DAYS["W"]}
    return {"method": METHOD, "periods": DAILY_PERIODS, "max_gap_days": MAX_GAP_DAYS["D"]}


def _unit(freq: Freq) -> str:
    return "weeks" if freq == "W" else "days"


def _exclusions(windows: list[PromotionWindow] | None) -> list[tuple[date, date]]:
    """Promotions to leave out of a fit: each, and the 3 weeks after it (as the app does)."""
    return [(w.start, w.end + timedelta(days=POST_DAYS)) for w in windows or []]


def _warnings(values: pd.Series, freq: Freq, *sources, closed_days: int = 0) -> list[str]:
    """Every warning, once, in order (the decomposition's, then the statistic's), said plainly.

    ``closed_days`` were closures given to the decomposition as missing: they're
    named in their own note, so they don't count as days with no data.
    """
    seen: list[str] = []
    gaps = None
    for source in sources:
        for w in getattr(source, "warnings", None) or []:
            leading = re.match(r"\s*(\d+)", w.message)
            n = int(leading.group(1)) if leading else None
            if w.code == "IMPUTED_DAYS" and n is not None and closed_days:
                n -= closed_days
                if n <= 0:
                    continue
            if gaps is None:
                gaps = _weekend_share(values, freq)
            text = wording.plain_warning(
                w.code, w.message, n,
                MAX_GAP_DAYS[freq] // (7 if freq == "W" else 1), gaps,
            )
            if text not in seen:
                seen.append(text)
    return seen


def _weekend_share(values: pd.Series, freq: Freq) -> float:
    """Of the days with no row between the first and the last, the share on a Saturday or Sunday."""
    if freq != "D":
        return 0.0
    present = values.dropna().index
    if len(present) < 2:
        return 0.0
    missing = pd.date_range(present.min(), present.max()).difference(present)
    return float((missing.dayofweek >= 5).mean()) if len(missing) else 0.0


def _history_length(values: pd.Series, freq: Freq) -> int:
    present = values.dropna()
    if present.empty:
        return 0
    step = 7 if freq == "W" else 1
    return int((present.index[-1] - present.index[0]).days // step) + 1


# =============================================================================
# A period's verdict
# =============================================================================


class PeriodRow(BaseModel):
    """One group's verdict on the period."""

    group: str
    verdict: Outcome
    label: str = Field(description="Expected, Real change, Noise or Not enough data.")
    summary: str = Field(description="The verdict in a sentence, in the app's words.")
    detail: str | None = Field(default=None, description="The expected figure and range, and the change vs the previous period.")
    period_start: str
    period_end: str
    observed: float | None = None
    expected: float | None = None
    expected_low: float | None = None
    expected_high: float | None = None
    change_pct: float | None = Field(default=None, description="Percent change vs the previous period of the same length.")
    p_value: float | None = None
    promotions_in_period: list[str] = Field(default_factory=list, description="Promotions that ran during the period, if any were given.")
    insufficient_reason: str | None = None
    warnings: list[str] = Field(default_factory=list)


def default_period(values: list[pd.Series], freq: Freq) -> tuple[date, date]:
    """The latest week: the last weekly row, or the last 7 days of daily rows."""
    last = max(v.dropna().index.max() for v in values if not v.dropna().empty)
    if freq == "W":
        return last.date(), last.date()
    return (last - pd.Timedelta(days=6)).date(), last.date()


def judge_period(
    group: GroupSeries,
    freq: Freq,
    week_label: WeekLabel,
    kind: str,
    period: tuple[date, date],
    currency: str | None,
    promotions: list[PromotionWindow] | None = None,
) -> PeriodRow:
    values = group.values
    start, end = pd.Timestamp(period[0]), pd.Timestamp(period[1])
    if freq == "W":
        last_row = max(values.index.max(), end + pd.Timedelta(days=7))
        grid = pd.date_range(values.index.min(), last_row, freq=weekly_freq(values.index))
        labels = weeks_overlapping(grid, start, end, week_label)
        if len(labels) == 0:
            raise ValueError(f"No week in the data falls in {wording.span(period[0], period[1])}.")
        period_values = values.reindex(labels)
        # On the full weekly grid up to the week before the period: a group
        # whose rows stop early (a delisted product) has missing weeks there,
        # which are trimmed, not read as data left out.
        history = values.reindex(grid[grid < labels[0]])
        first, last = labels[0], labels[-1]
        min_points = 1
        weekly_period = len(labels) == 1
        prior_name = "week" if len(labels) == 1 else f"{len(labels)} weeks"
        period_days = (week_days(first, week_label)[0], week_days(last, week_label)[1])
    else:
        days = pd.date_range(start, end)
        period_values = values.reindex(days)
        history = values.reindex(pd.date_range(values.index.min(), start - pd.Timedelta(days=1)))
        first, last = days[0], days[-1]
        min_points = min(5, len(days))
        weekly_period = len(days) == 7
        prior_name = "week" if len(days) == 7 else f"{len(days)} days"
        period_days = (first, last)
    base = PeriodRow(
        group=group.label, verdict="insufficient", label=wording.VERDICT_LABEL["insufficient"], summary="",
        period_start=first.date().isoformat(), period_end=last.date().isoformat(),
    )
    running = [
        w.name or "a promotion" for w in promotions or []
        if pd.Timestamp(w.start) <= period_days[1] and pd.Timestamp(w.end) >= period_days[0]
    ]
    base = base.model_copy(update={"promotions_in_period": running})
    dec = decompose(history, exclude=_exclusions(promotions), **_decompose_options(freq, week_label))
    facts = dec if isinstance(dec, Insufficient) else verdict(
        dec, period_values, kind=SERIES_KIND[kind], min_points=min_points, **CAL
    )
    if isinstance(facts, Insufficient):
        rows_before = values.dropna()
        rows_before = rows_before[rows_before.index < first]
        if facts.reason == "TOO_FEW_POINTS" and facts.has == 0 and len(rows_before):
            # A product whose rows stopped before the period: delisted, say.
            summary = wording.no_rows_since(rows_before.index[-1].date(), freq == "W", week_label)
        else:
            summary = wording.insufficient(
                facts.reason, facts.needs, facts.has, facts.unit, context="period",
                weeks_of_history=_history_length(values[values.index <= last], freq) if freq == "W" else None,
            )
        return base.model_copy(update={
            "summary": summary,
            "insufficient_reason": facts.reason,
            # A product with no rows since says so; its trimmed weeks needn't be listed too.
            "warnings": [] if summary.startswith("There are no sales") else _warnings(values, freq, dec),
        })
    low, high = facts.expected_range
    change_abs, change_pct = facts.change_vs_prior
    detail = wording.period_detail(facts.expected, low, high, change_pct, kind, currency, prior_name)
    if running:
        detail += " " + wording.promotions_in_period(running, weekly_period)
    return base.model_copy(update={
        "verdict": facts.verdict,
        "label": wording.VERDICT_LABEL[facts.verdict],
        "summary": wording.period_sentence(facts.verdict, facts.observed, facts.expected, kind, currency, weekly_period),
        "detail": detail,
        "observed": facts.observed,
        "expected": facts.expected,
        "expected_low": low,
        "expected_high": high,
        "change_pct": change_pct,
        "p_value": facts.p_value,
        "warnings": _warnings(values, freq, dec, facts),
    })


# =============================================================================
# Seasonality
# =============================================================================


class MonthRow(BaseModel):
    month: int
    name: str
    effect_pct: float = Field(description="How far the month runs above (+) or below (−) the year's average, in percent.")
    lower: float
    upper: float
    line: str


class SeasonalityRow(BaseModel):
    """One group's seasonal pattern."""

    group: str
    found: bool
    summary: str
    months: list[MonthRow] = Field(default_factory=list)
    basis: str | None = None
    insufficient_reason: str | None = None
    warnings: list[str] = Field(default_factory=list)


def seasonality(
    group: GroupSeries, freq: Freq, week_label: WeekLabel, promotions: list[PromotionWindow] | None = None
) -> SeasonalityRow:
    """Each month's effect. With promotions given, their weeks (and the 3 after) are
    left out, so the months show the season, not this year's Black Friday."""
    unit = _unit(freq)
    dec = decompose(group.values, exclude=_exclusions(promotions), **_decompose_options(freq, week_label))
    effects = dec if isinstance(dec, Insufficient) else month_effects(dec, level=LEVEL)
    if isinstance(effects, Insufficient):
        return SeasonalityRow(
            group=group.label, found=False,
            summary=wording.insufficient(effects.reason, effects.needs, effects.has, effects.unit, context="seasonality"),
            insufficient_reason=effects.reason,
            warnings=_warnings(group.values, freq, dec),
        )
    months = [
        MonthRow(month=r.month, name=wording.MONTHS[r.month - 1], effect_pct=r.effect_pct, lower=r.lower, upper=r.upper,
                 line=wording.month_line(r.month, r.effect_pct, r.lower, r.upper))
        for r in effects.rows
    ]
    length = _history_length(group.values, freq)
    basis = f"Based on {wording.history(length, unit)} of data. Each range is where the month's effect likely lies (90%)."
    if dec.excluded:
        basis += " " + (wording.PROMOTIONS_LEFT_OUT if freq == "W" else wording.PROMOTION_DAYS_LEFT_OUT)
    return SeasonalityRow(
        group=group.label, found=True,
        summary=wording.seasonality_sentence(effects.rows),
        months=months,
        basis=basis,
        warnings=_warnings(group.values, freq, dec, effects),
    )


# =============================================================================
# A promotion's lift
# =============================================================================


class LiftPoint(BaseModel):
    date: str
    actual: float | None
    expected: float
    low: float
    high: float
    in_promotion: bool


class LiftRow(BaseModel):
    """One promotion in one group."""

    group: str
    promotion: str
    start: str
    end: str
    verdict: Outcome
    label: str
    summary: str
    value: str | None = Field(default=None, description="'+32%', the app's headline figure.")
    amount: str | None = Field(default=None, description="'£9,144 more than expected'.")
    range: str | None = Field(default=None, description="'likely between +13% and +51%'; none beside an expected verdict.")
    estimate_pct: float | None = None
    interval_pct: tuple[float, float | None] | None = Field(
        default=None,
        description=(
            "The likely range in percent: the test inverted, so it widens with the lift and excludes "
            "zero exactly when the verdict's test does. The top is None when it's unbounded."
        ),
    )
    estimate: float | None = None
    interval: tuple[float, float] | None = Field(
        default=None,
        description=(
            "The likely range as an amount: the estimate plus or minus the test's percentage "
            "half-width of the expected total, so it excludes zero exactly when the percentage range does."
        ),
    )
    observed_total: float | None = None
    expected_total: float | None = None
    p_value: float | None = None
    periods_in_window: list[str] = Field(default_factory=list, description="The weeks (or days) counted as the promotion.")
    series: list[LiftPoint] | None = Field(default=None, description="Each period around it, actual against expected, for a chart.")
    after_summary: str | None = Field(
        default=None, description="The 3 weeks (or 21 days) just after it, against expected: a dip if customers stocked up."
    )
    after_pct: float | None = Field(default=None, description="Sales in the weeks after, in percent vs expected.")
    after_difference: float | None = Field(default=None, description="Sales in the weeks after, minus expected.")
    insufficient_reason: str | None = None
    warnings: list[str] = Field(default_factory=list)


def lift(
    group: GroupSeries,
    window: PromotionWindow,
    others: list[PromotionWindow],
    freq: Freq,
    week_label: WeekLabel,
    kind: str,
    currency: str | None,
    include_series: bool,
) -> LiftRow:
    name = window.name or "The promotion"
    base = LiftRow(
        group=group.label, promotion=name, start=window.start.isoformat(), end=window.end.isoformat(),
        verdict="insufficient", label=wording.VERDICT_LABEL["insufficient"], summary="",
    )
    options = _decompose_options(freq, week_label)
    method = options.pop("method")
    values, closures, longest = _closures(group.values, window, freq)
    if closures:
        options["max_gap_days"] = longest
    facts = its_lift(
        values,
        (window.start, window.end),
        kind=SERIES_KIND[kind],
        method=method,
        other_windows=[(w.start, w.end) for w in others],
        noise_band="none",
        post_days=POST_DAYS,
        baseline_days=BASELINE_DAYS,
        baseline_lookback_days=BASELINE_LOOKBACK_DAYS,
        level=LEVEL,
        # The weeks after are always read, for the pull-forward check.
        series_days_before=SERIES_DAYS_BEFORE if include_series else 0,
        series_days_after=SERIES_DAYS_AFTER,
        **CAL,
        **options,
    )
    if isinstance(facts, Insufficient):
        reason_code = facts.reason
        present = group.values.dropna()
        first_year = len(present) and pd.Timestamp(window.start) < present.index[0] + pd.Timedelta(days=365 + BASELINE_DAYS)
        if reason_code == "BASELINE_TOO_SHORT" and first_year:
            # The baseline is short because nothing a year back gives its season.
            reason_code = "NO_SEASONAL_BEFORE"
        reason = wording.insufficient(
            reason_code, facts.needs, facts.has, facts.unit, context="promotion",
            weeks_of_history=_history_length(group.values, freq),
        )
        return base.model_copy(update={
            "summary": f"{name}, {wording.span(window.start, window.end)}: {reason}",
            "insufficient_reason": reason_code,
        })
    # One basis for both ranges. The verdict and the percentage range rank the
    # past errors as percentages of what was expected then; the series' amount
    # range ranks them as raw amounts, which on a series that has grown (or
    # shrunk) understates (or overstates) today's uncertainty. So the amount
    # range shown is the test's percentage half-width applied to today's
    # expected total. An amount's error (expected minus what would have sold)
    # doesn't grow with the lift, so that range holds at any lift.
    interval = facts.interval_abs
    if facts.interval_pct is not None and facts.counterfactual_total > 0:
        interval = (
            facts.counterfactual_total * facts.interval_pct[0] / 100,
            facts.counterfactual_total * facts.interval_pct[1] / 100,
        )
    interval_pct = _percent_range(facts.estimate_pct, facts.interval_pct)
    value = wording.lift_value(facts.estimate_pct, facts.estimate_abs, kind, currency)
    amount_text = wording.lift_amount(facts.estimate_abs, kind, currency)
    range_text = wording.lift_range(facts.verdict, interval_pct, interval, kind, currency)
    periods = facts.params.get("window_weeks") or [
        d.date().isoformat() for d in pd.date_range(window.start, window.end)
    ]
    points = [
        LiftPoint(date=p.date.isoformat(), actual=p.actual, expected=p.expected, low=p.low, high=p.high, in_promotion=p.in_window)
        for p in facts.series or []
    ]
    after = _after(
        points, periods[-1], facts.params.get("series_band_half_width"), freq, kind, currency,
        window.end, _next_promotion(window, others), week_label,
    )
    summary = wording.lift_sentence(name, window.start, window.end, value, amount_text, range_text, facts.verdict)
    if after and not after["summary"].endswith("about as expected."):
        summary += " " + after["summary"]
    return base.model_copy(update={
        "verdict": facts.verdict,
        "label": wording.VERDICT_LABEL[facts.verdict],
        "summary": summary,
        "after_summary": after["summary"] if after else None,
        "after_pct": after["pct"] if after else None,
        "after_difference": after["difference"] if after else None,
        "value": value,
        "amount": amount_text,
        "range": range_text,
        "estimate_pct": facts.estimate_pct,
        "interval_pct": interval_pct,
        "estimate": facts.estimate_abs,
        "interval": interval,
        "observed_total": facts.observed_total,
        "expected_total": facts.counterfactual_total,
        "p_value": facts.p_value,
        "periods_in_window": periods,
        "series": points if include_series else None,
        "warnings": (
            _warnings(group.values, freq, facts, closed_days=sum((b - a).days + 1 for a, b in closures))
            + _lift_notes(group.values, window, closures)
        ),
    })


def _percent_range(estimate_pct: float | None, interval_pct: tuple[float, float] | None) -> tuple[float, float | None] | None:
    """The likely range in percent, as the test inverted.

    The test's range is the estimate plus or minus q, the 90% point of the
    past errors as a percentage of what was expected. Those errors were
    measured with no promotion; a lift L multiplies a window's percentage
    error by (1 + L), so plus or minus q is too narrow for a large lift (on
    UCI Online Retail II it held a +80% lift 65% of the time). The values of L
    the test doesn't reject are those with |e − L| ≤ q(1 + L):
    from (e − q)/(1 + q) to (e + q)/(1 − q), unbounded above when q ≥ 1.
    It excludes zero exactly when |e| > q, as the test's range does.
    """
    if estimate_pct is None or interval_pct is None:
        return interval_pct
    e = estimate_pct / 100
    q = max(e - interval_pct[0] / 100, interval_pct[1] / 100 - e)
    low = 100 * (e - q) / (1 + q)
    high = 100 * (e + q) / (1 - q) if q < 1 else None
    return (low, high)


def _closures(values: pd.Series, window: PromotionWindow, freq: Freq) -> tuple[pd.Series, list[tuple[date, date]], int]:
    """Runs of CLOSURE_MIN_DAYS or more days with no sales, as missing days.

    Read as zeros, a closure drags down what's expected after it (on UCI
    Online Retail II the Christmas closure made most January windows read as a
    real change) and widens every range through the past errors around it.
    As missing days, they're filled from the days either side for the fit,
    and the baseline skips them. Only in a store that sells on most days
    (the median day isn't zero), never inside the promotion, and not when the
    series has a real gap longer than the limit (that says it's insufficient,
    as before). Returns the series, the runs, and the gap limit to pass.
    """
    limit = MAX_GAP_DAYS[freq]
    present = values.dropna()
    if freq != "D" or present.empty or float(present.median()) <= 0:
        return values, [], limit
    full = values.reindex(pd.date_range(present.index.min(), present.index.max(), freq="D"))
    if _longest_run(full.isna()) > limit:
        return values, [], limit
    start, end = pd.Timestamp(window.start), pd.Timestamp(window.end)
    runs = []
    zero = full.eq(0).to_numpy()
    i = 0
    while i < len(full):
        if not zero[i]:
            i += 1
            continue
        j = i
        while j + 1 < len(full) and zero[j + 1]:
            j += 1
        a, b = full.index[i], full.index[j]
        if j - i + 1 >= CLOSURE_MIN_DAYS and (b < start or a > end):
            runs.append((a.date(), b.date()))
        i = j + 1
    if not runs:
        return values, [], limit
    for a, b in runs:
        full.loc[pd.Timestamp(a):pd.Timestamp(b)] = float("nan")
    return full, runs, max(limit, _longest_run(full.isna()))


def _longest_run(mask: pd.Series) -> int:
    longest = current = 0
    for flag in mask.to_numpy():
        current = current + 1 if flag else 0
        longest = max(longest, current)
    return longest


def _lift_notes(values: pd.Series, window: PromotionWindow, closures: list[tuple[date, date]]) -> list[str]:
    """Notes on what the promotion was judged against: closures left out, one shortly before it, and one earlier year."""
    notes = []
    if closures:
        notes.append(wording.closures(closures))
        since = [(window.start - b).days for _, b in closures if b < window.start]
        if since and min(since) <= REOPENING_DAYS:
            notes.append(wording.after_closure(min(since)))
    present = values.dropna()
    if len(present) and (pd.Timestamp(window.start) - present.index[0]).days < ONE_YEAR_HISTORY_DAYS:
        notes.append(wording.ONE_EARLIER_YEAR)
    return notes


def _next_promotion(window: PromotionWindow, others: list[PromotionWindow]) -> date | None:
    """The first day another promotion takes of the 3 weeks after this one, if any does."""
    after_end = window.end + timedelta(days=POST_DAYS)
    starts = [max(o.start, window.end + timedelta(days=1)) for o in others if o.end > window.end and o.start <= after_end]
    return min(starts) if starts else None


def _after(
    points: list[LiftPoint], last_in_window: str, half: float | None, freq: Freq, kind: str, currency: str | None,
    window_end: date | None = None, next_start: date | None = None, week_label: WeekLabel = "end",
) -> dict | None:
    """The weeks just after a promotion against expected, from the lift's own series.

    The expected line is the lift's counterfactual, carried on. A difference
    counts as a dip (or a rise) only beyond the range those weeks usually
    vary by: one step's 90% half-width times the square root of the steps.

    Another promotion starting in those weeks would read as this one's
    after-effect (SUMMER40's "stayed 19% above expected" was FLASH20), so only
    the days before it are judged, and with fewer than MIN_AFTER_DAYS of them,
    nothing is: the sentence says why.
    """
    # The 3 weeks after, by the calendar: days without a row (a closed
    # weekend) are left out of the sums, not counted as part of the span.
    end = (pd.Timestamp(last_in_window) + pd.Timedelta(days=POST_DAYS)).date().isoformat()
    after = [p for p in points if last_in_window < p.date <= end and not p.in_promotion and p.actual is not None]
    clear_days = None
    if next_start is not None and window_end is not None:
        cut = pd.Timestamp(next_start)
        last_day = (lambda d: week_days(d, week_label)[1]) if freq == "W" else (lambda d: d)  # noqa: E731
        after = [p for p in after if last_day(pd.Timestamp(p.date)) < cut]
        clear_days = (next_start - window_end).days - 1
        if clear_days < MIN_AFTER_DAYS or not after:
            return {"summary": wording.after_interrupted((next_start - window_end).days), "pct": None, "difference": None}
    if not after:
        return None
    actual = sum(p.actual for p in after)
    expected = sum(p.expected for p in after)
    difference = actual - expected
    pct = 100 * difference / expected if expected > 0 else None
    beyond = half is not None and abs(difference) > half * math.sqrt(len(after))
    if freq == "W":
        steps, unit = len(after), "weeks"
    elif clear_days is not None:
        steps, unit = clear_days, "days"
    else:
        days = (pd.Timestamp(after[-1].date) - pd.Timestamp(last_in_window)).days
        steps, unit = (POST_DAYS // 7, "weeks") if days > 14 else (days, "days")
    return {
        "summary": wording.after_promotion(pct, difference, steps, unit, beyond, kind, currency, before_next=clear_days is not None),
        "pct": pct,
        "difference": difference,
    }


def overview(rows: list[Any], what: str) -> str:
    """"2 of 12 groups had a real change." for many groups; the row's own sentence for one."""
    if len(rows) == 1:
        return rows[0].summary
    counts = {k: sum(1 for r in rows if r.verdict == k) for k in ORDER}
    parts = [f"{counts['real change']} of {len(rows)} {what} had a real change"]
    if counts["insufficient"]:
        parts.append(f"{counts['insufficient']} had too little data to judge")
    return "; ".join(parts) + "."
