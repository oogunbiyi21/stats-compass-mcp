"""Seasonal decomposition of a daily series: trend + seasonal + remainder.

Three methods behind one signature, so they can be compared on the same data:

- ``mstl``: statsmodels MSTL on the daily series, one seasonal component per
  period (by default weekly and annual).
- ``stl``: STL with period 52 on Monday-start weekly sums. The annual pattern
  only; a weekly grain has no day-of-week pattern to find.
- ``fourier``: least squares on a linear trend, day-of-week effects and
  ``fourier_terms`` annual harmonics.

All are additive: a store can have days of zero or negative net revenue, which
a multiplicative model cannot represent.

**Why the annual component is smoothed.** With two years of history, a daily
annual component is estimated from two values per day of the year, and it
follows the noise in them. On patternless data MSTL's remainder had a tenth of
the true noise's spread, so bands and tests built on the remainder called
ordinary weeks a real change. ``annual_smoothing_days`` replaces the annual
component with a centred moving average of itself and returns what it removed
to the remainder. A one-day spike such as Black Friday therefore lands in the
remainder, not in the seasonal pattern. Set it to 0 to see the raw component.
The Fourier method is smooth by construction and is not smoothed again.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date
from typing import Any, Literal, Sequence

import numpy as np
import pandas as pd

from stats_compass_core.results import ToolWarning
from stats_compass_core.series._common import (
    Freq,
    Insufficient,
    WeekLabel,
    prepare_daily,
    prepare_weekly,
    week_start,
)

Method = Literal["mstl", "stl", "fourier"]
TrendAhead = Literal["level", "flat", "linear"]

WEEKLY_PERIOD = 52
# Periods at least this long are treated as the annual pattern, and smoothed.
ANNUAL_MIN_PERIOD_DAYS = 300


@dataclass(frozen=True)
class WeeklyComponents:
    """The decomposition as Monday-start weekly sums, complete weeks only."""

    observed: pd.Series
    trend: pd.Series
    seasonal: pd.Series
    remainder: pd.Series


@dataclass(frozen=True, eq=False)
class Decomposition:
    """An additive decomposition: ``observed = trend + seasonal + remainder``.

    Series are indexed by day (``grain == "day"``) or by the Monday that starts
    each week (``grain == "week"``). ``observed`` is the series decomposed, with
    imputed days filled in; ``daily`` is the same input at daily grain, whatever
    the method.

    On ``excluded`` days the remainder is NaN: their values were left out of
    the fit, so nothing observed is left over. Everything that measures noise
    skips them.
    """

    method: str
    grain: Literal["day", "week"]
    params: dict[str, Any]
    observed: pd.Series
    trend: pd.Series
    seasonal: pd.Series
    remainder: pd.Series
    seasonal_by_period: dict[int, pd.Series]
    imputed: list[date]
    warnings: list[ToolWarning]
    daily: pd.Series = field(repr=False, default_factory=lambda: pd.Series(dtype=float))
    day_of_week_share: tuple[float, ...] | None = field(default=None, repr=False)
    excluded: list[date] = field(default_factory=list)
    # The Fourier fit's least-squares pieces, so a past window can be deleted
    # from it exactly (see expectation_errors). None for the STL methods.
    linear: dict[str, Any] | None = field(default=None, repr=False)
    trimmed: list[date] = field(default_factory=list)

    # -- the step ------------------------------------------------------------

    @property
    def unit(self) -> Literal["day", "week"]:
        """The step of the series the expectation is measured on.

        ``"day"`` for daily input, whatever the grain (the ``stl`` method sums
        daily input into weeks but still measures on days). ``"week"`` for
        weekly input (``decompose(freq="W")``): there are no days to measure
        on, so every count of days in ``params`` is read in whole weeks.
        """
        return "week" if self.params.get("input_freq") == "W" else "day"

    @property
    def base(self) -> pd.Series:
        """The input at its own step: ``daily`` for daily input, else the weeks."""
        return self.observed if self.unit == "week" else self.daily

    def _steps(self, days: int) -> int:
        """A count of days in ``params``, as a count of the input's steps."""
        return days if self.unit == "day" else days // 7

    # -- expectation ---------------------------------------------------------

    def expected_steps(self, labels: pd.DatetimeIndex) -> pd.Series:
        """Trend + seasonal at each of the input's own steps (weekly input)."""
        return pd.Series([self._expected_at(label) for label in labels], index=labels)

    def expected_daily(self, start: date, end: date) -> pd.Series:
        """Trend + seasonal for each day in ``[start, end]``, in-sample or ahead.

        To judge a period, decompose the history that ends the day before it
        and read the expectation ahead. An in-sample expectation has already
        absorbed the period: the trend bends towards it, and a real change
        reads as expected. ``verdict`` refuses a decomposition that overlaps
        the period for that reason.

        Ahead of the data, each seasonal component repeats its value from whole
        periods earlier and the trend follows ``params["trend_ahead"]``. A
        weekly-grain decomposition apportions each week's expectation over its
        days by the store's day-of-week shares.
        """
        if self.unit == "week":
            raise ValueError(
                "weekly input has no daily expectation; use expected_steps"
            )
        days = pd.date_range(pd.Timestamp(start), pd.Timestamp(end), freq="D")
        if len(days) == 0:
            return pd.Series(dtype=float)
        if self.grain == "day":
            return pd.Series([self._expected_at(day) for day in days], index=days)
        weeks = week_start(days)
        shares = np.asarray(self.day_of_week_share)
        values = [
            self._expected_at(week) * shares[day.dayofweek]
            for day, week in zip(days, weeks)
        ]
        return pd.Series(values, index=days)

    def expected_total(self, start: date, end: date) -> float:
        """The sum of ``expected_daily`` over ``[start, end]``."""
        return float(self.expected_daily(start, end).sum())

    def _expected_at(self, when: pd.Timestamp) -> float:
        first, last = self.trend.index[0], self.trend.index[-1]
        if when < first:
            raise ValueError(
                f"{when.date()} is before the decomposed series starts ({first.date()})"
            )
        if when <= last:
            return float(self.trend.loc[when] + self.seasonal.loc[when])
        return self._trend_ahead(when) + sum(
            self._seasonal_ahead(component, period, when)
            for period, component in self.seasonal_by_period.items()
        )

    def _step(self) -> pd.Timedelta:
        return pd.Timedelta(days=1 if self.grain == "day" else 7)

    def _seasonal_ahead(
        self, component: pd.Series, period: int, when: pd.Timestamp
    ) -> float:
        span = period * self._step()
        back = when - span
        while back > component.index[-1]:
            back -= span
        return float(component.loc[back])

    def _trend_ahead(self, when: pd.Timestamp) -> float:
        window = max(
            1,
            round(self.params["trend_window_days"] / (1 if self.grain == "day" else 7)),
        )
        if self.params["trend_ahead"] == "level":
            # The same adjustment expectation_errors makes at past positions:
            # the seasonal read one period earlier, per day.
            daily_level, _ = self._level_from_real_days()
            if self.unit == "week":
                return daily_level  # read from weeks, so already a week's level
            return daily_level if self.grain == "day" else 7 * daily_level
        recent = self.trend.iloc[-window:]
        if self.params["trend_ahead"] == "flat":
            return float(recent.mean())
        slope = (recent.iloc[-1] - recent.iloc[0]) / max(len(recent) - 1, 1)
        steps = (when - self.trend.index[-1]) / self._step()
        return float(recent.iloc[-1] + slope * steps)

    def _level_from_real_days(self) -> tuple[float, int]:
        """Mean seasonally adjusted value over the last real days, and how many.

        Walks back past excluded and imputed days, up to
        ``level_lookback_days``, until it has ``trend_window_days`` real ones.
        Refilled days are the fit's own values: a level read from them reads
        the fit back to itself, and with a recent promotion excluded the
        verdict's test fired five times its nominal rate.

        Below half a window of real days (back-to-back promotions with their
        tails, or the year-back seasonal still missing) the level is not
        trusted. The last window is used as it is, so ``expected_daily`` still
        answers, but ``decompose`` records the count in
        ``params["level_real_days"]`` with a ``RECENT_DAYS_FILLED`` warning,
        and ``verdict`` and ``forecast`` refuse.

        The real days need not be contiguous, while the reference's baselines
        are. On a growing store that makes the level slightly stale (about 1%
        of level on the demo's growth with a full lookback).
        """
        days = self._steps(int(self.params["trend_window_days"]))
        lookback = self._steps(int(self.params.get("level_lookback_days", 3 * days)))
        adjusted = self.base - self._lagged_seasonal_daily()
        filled = set(self.imputed) | set(self.excluded)
        chosen = []
        recent = zip(
            adjusted.index[::-1][:lookback], adjusted.to_numpy()[::-1][:lookback]
        )
        for day, value in recent:
            if day.date() in filled or not np.isfinite(value):
                continue
            chosen.append(value)
            if len(chosen) == days:
                break
        if len(chosen) * 2 < days:
            return float(adjusted.iloc[-days:].mean()), len(chosen)
        return float(np.mean(chosen)), len(chosen)

    def _fitted_daily(self) -> pd.Series:
        """In-sample trend + seasonal, per day, whatever the grain (per week for weekly input)."""
        if self.grain == "day" or self.unit == "week":
            return self.trend + self.seasonal
        days = self.daily.index
        weekly = (self.trend + self.seasonal).reindex(week_start(days)).to_numpy()
        shares = np.asarray(self.day_of_week_share)[days.dayofweek]
        return pd.Series(weekly * shares, index=days)

    def _seasonal_daily(self) -> pd.Series:
        """The in-sample seasonal pattern, per day, whatever the grain (per week for weekly input)."""
        if self.grain == "day" or self.unit == "week":
            return self.seasonal
        days = self.daily.index
        weekly = self.seasonal.reindex(week_start(days)).to_numpy()
        shares = np.asarray(self.day_of_week_share)[days.dayofweek]
        return pd.Series(weekly * shares, index=days)

    def _lagged_seasonal_daily(self) -> pd.Series:
        """The seasonal pattern as a forecast reads it: one period earlier, per day.

        Per week for weekly input.
        """
        days = self.base.index
        lagged = pd.Series(0.0, index=days)
        for period, component in self.seasonal_by_period.items():
            shifted = component.shift(period)
            if self.grain == "day" or self.unit == "week":
                lagged = lagged + shifted.reindex(days).to_numpy()
            else:
                shares = np.asarray(self.day_of_week_share)[days.dayofweek]
                lagged = lagged + shifted.reindex(week_start(days)).to_numpy() * shares
        return lagged

    def expectation_errors(
        self, ndays: int, out_of_sample: bool = True, delete_after_days: int = 0
    ) -> pd.DataFrame:
        """How wrong the expectation has been, at every past position it can be tried.

        At each position the estimator ``expected_*`` uses ahead of the data:
        the mean of the seasonally adjusted values over the
        ``trend_window_days`` before, times ``ndays``, plus the seasonal
        pattern read one period earlier. The error is the observed total over
        the ``ndays`` from that position, minus that expectation.

        Why not the remainder: the fit has already absorbed part of each past
        window's own noise, which the period being judged never gets. Tests
        built on remainder windows fired at three times their nominal rate.

        Out of sample: with two cycles, the seasonal one period before a past
        position was fitted with that position's own values in it, so its
        error comes out too small. The period really being judged was never
        in the fit. For the Fourier fit (``out_of_sample=True``) each window's
        rows, and ``delete_after_days`` after it, are deleted from the least
        squares solution exactly before its seasonal is read: a closed-form
        update, no refit. The STL methods have no closed form, so their
        errors stay in sample and slightly too small (about 1.2x on null
        data). ``attrs["reference"]`` says which.

        Returns one row per window start, with ``error`` and ``expected``.
        Positions whose baseline or window touches an excluded day are left
        out.

        For weekly input every count is in weeks: ``ndays`` and
        ``delete_after_days`` are numbers of weeks, and the baseline is
        ``trend_window_days`` read in whole weeks.
        """
        if ndays < 1:
            raise ValueError("ndays must be at least 1")
        baseline = self._steps(int(self.params["trend_window_days"]))
        lagged = self._lagged_seasonal_daily()
        adjusted = self.base - lagged
        level = adjusted.rolling(baseline).mean().shift(1)
        ahead = lambda s: s.rolling(ndays).sum().shift(-(ndays - 1))  # noqa: E731
        expected = ndays * level + ahead(lagged)
        error = ahead(self.base) - expected
        frame = pd.DataFrame({"error": error, "expected": expected})
        if self.excluded:
            touched = pd.Series(0.0, index=self.base.index)
            touched.loc[pd.DatetimeIndex(self.excluded)] = 1.0
            span = touched.rolling(baseline + ndays).sum().shift(-(ndays - 1))
            frame = frame[span.fillna(1.0) == 0]
        frame = frame.dropna()
        exact = out_of_sample and self.linear is not None
        if exact:
            shift = self._deletion_shift(
                frame.index, ndays, baseline, delete_after_days
            )
            frame = frame.assign(
                error=frame["error"] - shift, expected=frame["expected"] + shift
            )
        frame.attrs["reference"] = "out_of_sample_exact" if exact else "in_sample"
        return frame

    def _deletion_delta(self, rows: np.ndarray) -> np.ndarray:
        """How far the coefficients move when ``rows`` are deleted from the fit."""
        lin = self.linear
        X_b = lin["X"][rows]
        hat = X_b @ lin["xtx_inv"] @ X_b.T
        u = np.linalg.solve(np.eye(len(rows)) - hat, lin["resid"][rows])
        return lin["xtx_inv"] @ X_b.T @ u

    def _deletion_shift(
        self, starts: pd.DatetimeIndex, ndays: int, baseline: int, after: int
    ) -> np.ndarray:
        """Per window start, how much the expectation moves with its rows deleted.

        The error is linear in the coefficients: error = c + g·beta, with
        g = ndays × mean(Z over the baseline) − sum(Z over the window), where
        Z is the lagged-seasonal design. Deleting the window's rows moves the
        coefficients by -delta, so the expectation moves by g·delta.
        """
        Z = self.linear["Z"]
        n = len(Z)
        positions = self.base.index.get_indexer(starts)
        shifts = np.empty(len(positions))
        for j, p in enumerate(positions):
            g = ndays * Z[p - baseline : p].mean(axis=0) - Z[p : p + ndays].sum(axis=0)
            rows = np.arange(p, min(p + ndays + after, n))
            shifts[j] = g @ self._deletion_delta(rows)
        return shifts

    def without_annual(self) -> Decomposition | None:
        """The same decomposition with the annual period dropped, or None.

        For callers whose error reference needs history behind the annual
        pattern: reading the seasonal one year back leaves the first year with
        nothing to measure against, so a store just past a year would get
        less than one just under it. The fallback keeps the weekly pattern,
        carries over what was imputed, excluded and trimmed, and says why the
        annual pattern was dropped. None for a weekly-grain decomposition
        (its only period is annual) or one with no annual period to drop.
        """
        keep = [p for p in self.seasonal_by_period if p < ANNUAL_MIN_PERIOD_DAYS]
        if self.grain != "day" or not keep or len(keep) == len(self.seasonal_by_period):
            return None
        options = {
            key: self.params[key]
            for key in (
                "max_gap_days",
                "annual_smoothing_days",
                "fourier_terms",
                "trend_ahead",
                "trend_window_days",
                "robust",
                "exclude_iterations",
                "level_lookback_days",
            )
        }
        exclude = [
            (pd.Timestamp(a).date(), pd.Timestamp(b).date())
            for a, b in self.params["exclude"]
        ]
        fallback = decompose(
            self.daily, method=self.method, periods=keep, exclude=exclude, **options
        )
        if isinstance(fallback, Insufficient):
            return None
        warning = ToolWarning(
            code="ANNUAL_DROPPED",
            columns=[],
            message=(
                f"The annual pattern left too little history behind it to measure "
                f"the expectation's error ({len(self.daily)} days; the first year "
                f"is used up reading the seasonal a year back), so only "
                f"{keep} were used. Expectations do not allow for the time of year."
            ),
        )
        result = replace(
            fallback,
            imputed=self.imputed,
            trimmed=self.trimmed,
            warnings=[
                *(w for w in self.warnings if w.code != "RECENT_DAYS_FILLED"),
                *(w for w in fallback.warnings if w.code == "RECENT_DAYS_FILLED"),
                warning,
            ],
            params={
                **fallback.params,
                "periods": self.params["periods"],
                "annual_fallback": True,
            },
        )
        # The refit saw the filled series, with no gaps left in it: count the
        # level's real days again now that the imputed days are known.
        _record_level(result, [])
        return result

    # -- noise ---------------------------------------------------------------

    def residual_sigma(self, ndays: int, robust: bool = False) -> float:
        """Spread of the remainder summed over ``ndays`` consecutive days.

        Measured, not modelled: the spread of every ``ndays``-day rolling sum,
        so autocorrelation in the remainder is reflected without being
        specified. A weekly grain gives whole weeks exactly and scales anything
        else by the square root of its length.

        ``robust=False`` is the standard deviation. ``robust=True`` is
        1.4826 × the median absolute deviation, which matches it on plain noise
        but is not widened by the store's own past spikes (each Black Friday
        sits in the remainder).
        """
        if ndays < 1:
            raise ValueError("ndays must be at least 1")
        if self.grain == "day" or self.unit == "week":
            # Weekly input: ``ndays`` counts weeks, as everywhere for it.
            return _spread(self.remainder.rolling(ndays).sum().dropna(), robust)
        if ndays % 7 == 0:
            return _spread(self.remainder.rolling(ndays // 7).sum().dropna(), robust)
        return _spread(self.remainder.dropna(), robust) * float(np.sqrt(ndays / 7))

    # -- display -------------------------------------------------------------

    def weekly(self) -> WeeklyComponents:
        """Monday-start weekly sums, complete weeks only, whatever the method."""
        parts = {
            "observed": self.observed,
            "trend": self.trend,
            "seasonal": self.seasonal,
            "remainder": self.remainder,
        }
        if self.grain == "week":
            return WeeklyComponents(**parts)
        weeks = week_start(self.observed.index)
        complete = (
            pd.Series(1, index=self.observed.index).groupby(weeks).transform("size")
            == 7
        )
        summed = {
            name: series[complete.to_numpy()].groupby(weeks[complete.to_numpy()]).sum()
            for name, series in parts.items()
        }
        return WeeklyComponents(**summed)


def decompose(
    values: pd.Series,
    *,
    method: Method = "mstl",
    periods: Sequence[int] = (7, 365),
    max_gap_days: int = 7,
    annual_smoothing_days: int = 31,
    fourier_terms: int = 4,
    trend_ahead: TrendAhead = "level",
    trend_window_days: int = 28,
    robust: bool = False,
    exclude: Sequence[tuple[date, date]] = (),
    exclude_iterations: int = 3,
    level_lookback_days: int | None = None,
    freq: Freq = "D",
    week_label: WeekLabel = "end",
) -> Decomposition | Insufficient:
    """Decompose a daily (or weekly) series into trend, seasonal components and remainder.

    Args:
        values: One value per day, on a DatetimeIndex. NaN means no data, never
            zero; missing dates are treated the same way.
        method: ``"mstl"``, ``"stl"`` (weekly sums, period 52) or ``"fourier"``.
        periods: Seasonal periods in days, for ``mstl`` and ``fourier``.
        max_gap_days: The longest run of missing days filled by interpolation.
            A longer gap returns ``Insufficient(reason="GAP_TOO_LONG")``.
        annual_smoothing_days: Width of the centred moving average applied to
            the annual component (``mstl`` and ``stl``); 0 disables it.
        fourier_terms: Annual harmonics, for ``fourier``.
        trend_ahead: How ``expected_*`` continues past the data. ``"level"``
            holds the mean of the seasonally adjusted values over the last
            ``trend_window_days``: the same estimator ``expectation_errors``
            measures in the past, so a test built on those errors fits it.
            ``"flat"`` holds the trend's mean over that window; ``"linear"``
            extends the trend's slope. At the end of the data a smoother sees
            one side only, and its end value carries more error than the
            data's own mean.
        trend_window_days: The window ``trend_ahead`` reads.
        robust: Robust LOESS fitting for ``mstl`` and ``stl`` alike, so that a
            comparison of the methods is not a comparison of robustness.
        exclude: ``(start, end)`` windows to leave out of the fit, such as a
            promotion being measured. Their values are replaced by
            interpolation for fitting; unlike a gap, they never make the series
            insufficient. They are returned in ``excluded``.
        level_lookback_days: How far back the level ahead may reach past
            excluded and imputed days to find ``trend_window_days`` real ones.
            Defaults to three windows. Less than half a window is a
            contradiction (every level would be refused) and raises.
        exclude_iterations: Excluded days start as a straight line between
            their neighbours, which is as noisy as the two days it joins. They
            are then replaced by the fit's own trend + seasonal and refitted,
            this many times.
        freq: ``"D"`` for one value per day (the default), ``"W"`` for one
            value per week, such as retailer sell-out data. Weekly input fits
            the annual pattern only (``periods`` is 52 weeks), with
            ``"fourier"`` (one year of history) or ``"stl"`` (two); every
            ``*_days`` argument must be whole weeks and is read in weeks. See
            ``_decompose_weekly``.
        week_label: For weekly input, which day of its week each date names:
            ``"end"`` (the week ending, usual for sell-out data) or
            ``"start"``. It decides which weeks an ``exclude`` window touches
            and which month each week falls in.

    Returns:
        A ``Decomposition``, or ``Insufficient`` when there is too little
        history for the method (``TOO_SHORT``) or a gap too long to fill.
    """
    if freq == "W":
        return _decompose_weekly(
            values,
            method=method,
            periods=periods,
            max_gap_days=max_gap_days,
            annual_smoothing_days=annual_smoothing_days,
            fourier_terms=fourier_terms,
            trend_ahead=trend_ahead,
            trend_window_days=trend_window_days,
            robust=robust,
            exclude=exclude,
            exclude_iterations=exclude_iterations,
            level_lookback_days=level_lookback_days,
            week_label=week_label,
        )
    if freq != "D":
        raise ValueError(f"unknown freq {freq!r}; use 'D' or 'W'")
    if level_lookback_days is None:
        level_lookback_days = 3 * trend_window_days
    elif level_lookback_days * 2 < trend_window_days:
        raise ValueError(
            f"level_lookback_days ({level_lookback_days}) must be at least half of "
            f"trend_window_days ({trend_window_days}), or every level is refused"
        )
    if method not in ("mstl", "stl", "fourier"):
        raise ValueError(f"unknown method {method!r}; use 'mstl', 'stl' or 'fourier'")
    periods = sorted({int(p) for p in periods})

    prepared = prepare_daily(values, max_gap_days, exclude)
    if isinstance(prepared, Insufficient):
        return prepared
    y, imputed = prepared.values, prepared.imputed

    # Fit the periods the history supports. A young store gets its weekly
    # pattern, and the annual variation lands in the remainder, widening the
    # bands, rather than the store getting nothing at all.
    if method == "stl":
        needs = 2 * WEEKLY_PERIOD * 7  # no weekly grain without the annual period
        if len(y) < needs:
            return Insufficient(
                needs=needs, has=len(y), unit="days", reason="TOO_SHORT"
            )
        periods_used = periods
    else:

        def supported(period: int) -> bool:
            if method == "fourier" and period >= ANNUAL_MIN_PERIOD_DAYS:
                return len(y) >= period  # one full cycle fixes the harmonics
            return len(y) >= 2 * period

        periods_used = [p for p in periods if supported(p)]
        if not periods_used:
            needs = 2 * min(periods)
            return Insufficient(
                needs=needs, has=len(y), unit="days", reason="TOO_SHORT"
            )
    dropped = [p for p in periods if p not in periods_used]

    params: dict[str, Any] = {
        "method": method,
        "periods": periods,
        "periods_used": periods_used,
        "max_gap_days": max_gap_days,
        "annual_smoothing_days": annual_smoothing_days,
        "fourier_terms": fourier_terms,
        "trend_ahead": trend_ahead,
        "trend_window_days": trend_window_days,
        "robust": robust,
        "exclude_iterations": exclude_iterations,
        "level_lookback_days": level_lookback_days,
        "exclude": [[_iso(start), _iso(end)] for start, end in exclude],
        "start": y.index[0].date().isoformat(),
        "end": y.index[-1].date().isoformat(),
        "n_days": len(y),
        "n_imputed": len(imputed),
        "n_excluded": len(prepared.excluded),
        "n_trimmed": len(prepared.trimmed),
    }
    columns = [str(values.name)] if values.name is not None else []
    warnings: list[ToolWarning] = []
    if prepared.trimmed:
        warnings.append(
            ToolWarning(
                code="TRIMMED_DAYS",
                columns=columns,
                message=(
                    f"{len(prepared.trimmed)} day(s) with no data before the first "
                    f"value or after the last were left out: there is nothing on one "
                    f"side to fill them from. The series runs {y.index[0].date()} to "
                    f"{y.index[-1].date()}."
                ),
            )
        )
    if imputed:
        warnings.append(
            ToolWarning(
                code="IMPUTED_DAYS",
                columns=columns,
                message=(
                    f"{len(imputed)} day(s) with no data were filled by linear "
                    f"interpolation before decomposing; the longest gap allowed is "
                    f"{max_gap_days} days."
                ),
            )
        )

    if dropped:
        warnings.append(
            ToolWarning(
                code="ANNUAL_DROPPED",
                columns=columns,
                message=(
                    f"{len(y)} days of history cannot support the period(s) "
                    f"{dropped}, so only {periods_used} were fitted. Variation over "
                    f"the year is in the remainder: expectations do not allow for "
                    f"the time of year, and bands are wider for it."
                ),
            )
        )

    def fit(values: pd.Series) -> Decomposition:
        if method == "mstl":
            return _mstl(
                values,
                periods_used,
                imputed,
                params,
                warnings,
                annual_smoothing_days,
                robust,
            )
        if method == "stl":
            return _stl_weekly(
                values, imputed, params, warnings, annual_smoothing_days, robust
            )
        return _fourier(values, periods_used, imputed, params, warnings, fourier_terms)

    dec = fit(y)
    if prepared.excluded:
        excluded_days = pd.DatetimeIndex(prepared.excluded)
        for _ in range(exclude_iterations):
            refilled = y.copy()
            refilled.loc[excluded_days] = dec._fitted_daily().loc[excluded_days]
            y = refilled
            dec = fit(y)
    dec = _account_for(dec, prepared.excluded, prepared.trimmed)
    _record_level(dec, columns)
    return dec


def _decompose_weekly(
    values: pd.Series,
    *,
    method: Method,
    periods: Sequence[int],
    max_gap_days: int,
    annual_smoothing_days: int,
    fourier_terms: int,
    trend_ahead: TrendAhead,
    trend_window_days: int,
    robust: bool,
    exclude: Sequence[tuple[date, date]],
    exclude_iterations: int,
    level_lookback_days: int | None,
    week_label: WeekLabel,
) -> Decomposition | Insufficient:
    """``decompose`` for one value per week.

    The same decomposition and the same reference machinery, at a weekly step:
    every ``*_days`` count is whole weeks (28 days is a four-week baseline),
    and ``Decomposition.unit`` is ``"week"`` so that the expectation, its
    errors and the level are all measured on weeks. Only the annual pattern
    is fitted, as 52 weeks: there is no day-of-week pattern in weekly totals.

    ``"fourier"`` needs one year (52 weeks), since one full cycle fixes the
    harmonics, and its reference is exactly out of sample; ``"stl"`` needs two
    (104 weeks). ``"mstl"`` with one period is STL, so it is refused rather
    than offered twice. Daily input never reaches this function, so nothing
    here can move a daily result.
    """
    if method not in ("fourier", "stl"):
        raise ValueError(
            f"weekly input: use method 'fourier' (recommended) or 'stl', not {method!r}"
        )
    if sorted({int(p) for p in periods}) not in ([7, 365], [WEEKLY_PERIOD]):
        raise ValueError(
            f"weekly input fits the annual pattern only: periods=({WEEKLY_PERIOD},)"
        )
    periods = [WEEKLY_PERIOD]
    if level_lookback_days is None:
        level_lookback_days = 3 * trend_window_days
    for name, days in (
        ("max_gap_days", max_gap_days),
        ("trend_window_days", trend_window_days),
        ("level_lookback_days", level_lookback_days),
    ):
        if days % 7:
            raise ValueError(
                f"weekly input counts whole weeks: {name} must be a multiple of 7, "
                f"not {days}"
            )
    if trend_window_days < 7:
        raise ValueError("weekly input: trend_window_days must be at least 7")
    if level_lookback_days * 2 < trend_window_days:
        raise ValueError(
            f"level_lookback_days ({level_lookback_days}) must be at least half of "
            f"trend_window_days ({trend_window_days}), or every level is refused"
        )

    prepared = prepare_weekly(values, max_gap_days // 7, exclude, week_label)
    if isinstance(prepared, Insufficient):
        return prepared
    y, imputed = prepared.values, prepared.imputed
    needs = WEEKLY_PERIOD if method == "fourier" else 2 * WEEKLY_PERIOD
    if len(y) < needs:
        return Insufficient(needs=needs, has=len(y), unit="weeks", reason="TOO_SHORT")

    params: dict[str, Any] = {
        "method": method,
        "periods": periods,
        "periods_used": periods,
        "input_freq": "W",
        "week_label": week_label,
        "max_gap_days": max_gap_days,
        "annual_smoothing_days": annual_smoothing_days,
        "fourier_terms": fourier_terms,
        "trend_ahead": trend_ahead,
        "trend_window_days": trend_window_days,
        "robust": robust,
        "exclude_iterations": exclude_iterations,
        "level_lookback_days": level_lookback_days,
        "exclude": [[_iso(start), _iso(end)] for start, end in exclude],
        "start": y.index[0].date().isoformat(),
        "end": y.index[-1].date().isoformat(),
        "n_weeks": len(y),
        "n_imputed": len(imputed),
        "n_excluded": len(prepared.excluded),
        "n_trimmed": len(prepared.trimmed),
    }
    columns = [str(values.name)] if values.name is not None else []
    warnings: list[ToolWarning] = []
    if prepared.trimmed:
        warnings.append(
            ToolWarning(
                code="TRIMMED_WEEKS",
                columns=columns,
                message=(
                    f"{len(prepared.trimmed)} week(s) with no data before the first "
                    f"value or after the last were left out: there is nothing on one "
                    f"side to fill them from. The series runs {y.index[0].date()} to "
                    f"{y.index[-1].date()}."
                ),
            )
        )
    if imputed:
        warnings.append(
            ToolWarning(
                code="IMPUTED_WEEKS",
                columns=columns,
                message=(
                    f"{len(imputed)} week(s) with no data were filled by linear "
                    f"interpolation before decomposing; the longest gap allowed is "
                    f"{max_gap_days // 7} week(s)."
                ),
            )
        )

    def fit(series: pd.Series) -> Decomposition:
        if method == "stl":
            return _stl_input_weekly(
                series, imputed, params, warnings, annual_smoothing_days, robust
            )
        return _fourier(
            series, periods, imputed, params, warnings, fourier_terms, step_days=7
        )

    dec = fit(y)
    if prepared.excluded:
        excluded_weeks = pd.DatetimeIndex(prepared.excluded)
        for _ in range(exclude_iterations):
            refilled = y.copy()
            refilled.loc[excluded_weeks] = dec._fitted_daily().loc[excluded_weeks]
            y = refilled
            dec = fit(y)
    dec = _account_for(dec, prepared.excluded, prepared.trimmed)
    _record_level(dec, columns)
    return dec


def _iso(day: Any) -> str:
    """A date, datetime or Timestamp as a plain ISO date."""
    return pd.Timestamp(day).date().isoformat()


def _record_level(dec: Decomposition, columns: list[str]) -> None:
    """Record how many real days the level ahead rests on, and warn below half.

    Called on the finished object, after imputed and excluded days are known:
    counted any earlier, filled days pass for real ones.
    """
    window = int(dec.params["trend_window_days"])
    _, real_days = dec._level_from_real_days()
    if dec.unit == "week":
        _record_level_weekly(dec, columns, window, real_days)
        return
    dec.params["level_real_days"] = real_days
    dec.warnings[:] = [w for w in dec.warnings if w.code != "RECENT_DAYS_FILLED"]
    if real_days * 2 < window:
        dec.warnings.append(
            ToolWarning(
                code="RECENT_DAYS_FILLED",
                columns=columns,
                message=(
                    f"Only {real_days} real day(s) in the last "
                    f"{dec.params['level_lookback_days']} were available to read the "
                    f"current level from (fewer than half of {window}); the rest were "
                    f"excluded, filled or have no seasonal a year back. Expectations "
                    f"ahead are not to be trusted."
                ),
            )
        )


def _record_level_weekly(
    dec: Decomposition, columns: list[str], window: int, real_weeks: int
) -> None:
    """``_record_level`` for weekly input: counted in weeks, kept in days.

    ``params["level_real_days"]`` stays in days (real weeks × 7), so that
    every reader compares it with ``trend_window_days`` as before.
    """
    dec.params["level_real_days"] = real_weeks * 7
    dec.warnings[:] = [w for w in dec.warnings if w.code != "RECENT_DAYS_FILLED"]
    if real_weeks * 2 < window // 7:
        dec.warnings.append(
            ToolWarning(
                code="RECENT_DAYS_FILLED",
                columns=columns,
                message=(
                    f"Only {real_weeks} real week(s) in the last "
                    f"{dec.params['level_lookback_days'] // 7} were available to read "
                    f"the current level from (fewer than half of {window // 7}); the "
                    f"rest were excluded, filled or have no seasonal a year back. "
                    f"Expectations ahead are not to be trusted."
                ),
            )
        )


def _account_for(
    dec: Decomposition, excluded: list[date], trimmed: list[date]
) -> Decomposition:
    """Attach what was excluded and trimmed; blank the remainder where excluded."""
    remainder = dec.remainder
    if excluded:
        days = pd.DatetimeIndex(excluded)
        hit = days if dec.grain == "day" or dec.unit == "week" else week_start(days).unique()
        remainder = remainder.copy()
        remainder.loc[remainder.index.isin(hit)] = np.nan
    return replace(dec, remainder=remainder, excluded=excluded, trimmed=trimmed)


def _spread(values: pd.Series, robust: bool) -> float:
    if robust:
        centred = values - values.median()
        return float(1.4826 * centred.abs().median())
    return float(values.std(ddof=1))


def _require_statsmodels():
    try:
        from statsmodels.tsa.seasonal import MSTL, STL
    except ImportError as exc:  # pragma: no cover - depends on the environment
        raise ImportError(
            "decompose needs statsmodels. Install with: pip install stats-compass-core[timeseries]"
        ) from exc
    return MSTL, STL


def _statsmodels_version() -> str:
    import statsmodels

    return statsmodels.__version__


def _smooth(component: pd.Series, width: int) -> pd.Series:
    if width <= 1:
        return component
    return component.rolling(width, center=True, min_periods=1).mean()


def _mstl(
    y, periods, imputed, params, warnings, annual_smoothing_days, robust
) -> Decomposition:
    MSTL, _ = _require_statsmodels()
    fit = MSTL(y, periods=periods, stl_kwargs={"robust": robust}).fit()
    seasonal_frame = (
        fit.seasonal.to_frame(f"seasonal_{periods[0]}")
        if isinstance(fit.seasonal, pd.Series)
        else fit.seasonal
    )
    params["statsmodels_version"] = _statsmodels_version()
    remainder = fit.resid.copy()
    components: dict[int, pd.Series] = {}
    for column in seasonal_frame.columns:
        # statsmodels names each component "seasonal_<period>"; match by name,
        # never by position.
        period = int(str(column).rsplit("_", 1)[1])
        component = seasonal_frame[column].rename(None)
        if period >= ANNUAL_MIN_PERIOD_DAYS and annual_smoothing_days > 1:
            smooth = _smooth(component, annual_smoothing_days)
            remainder = remainder + (component - smooth)
            component = smooth
        components[period] = component
    seasonal = sum(components.values())
    return Decomposition(
        method="mstl",
        grain="day",
        params=params,
        observed=y.rename(None),
        daily=y.rename(None),
        trend=fit.trend.rename(None),
        seasonal=seasonal,
        remainder=remainder.rename(None),
        seasonal_by_period=components,
        imputed=imputed,
        warnings=warnings,
    )


def _stl_weekly(
    y, imputed, params, warnings, annual_smoothing_days, robust
) -> Decomposition:
    _, STL = _require_statsmodels()
    weeks = week_start(y.index)
    complete = (
        pd.Series(1, index=y.index).groupby(weeks).transform("size").to_numpy() == 7
    )
    weekly = y[complete].groupby(weeks[complete]).sum()
    weekly.index = pd.DatetimeIndex(weekly.index, freq="W-MON")

    fit = STL(weekly, period=WEEKLY_PERIOD, robust=robust).fit()
    smoothing_weeks = (
        max(1, round(annual_smoothing_days / 7)) if annual_smoothing_days > 1 else 1
    )
    if smoothing_weeks > 1 and smoothing_weeks % 2 == 0:
        smoothing_weeks += 1
    annual = _smooth(fit.seasonal, smoothing_weeks)
    remainder = fit.resid + (fit.seasonal - annual)

    by_day = y.groupby(y.index.dayofweek).mean()
    shares = tuple(
        float(v) for v in (by_day / by_day.sum()).reindex(range(7), fill_value=1 / 7)
    )
    params.update(
        weekly_period=WEEKLY_PERIOD,
        annual_smoothing_weeks=smoothing_weeks,
        n_weeks=len(weekly),
        statsmodels_version=_statsmodels_version(),
    )
    return Decomposition(
        method="stl",
        grain="week",
        params=params,
        observed=weekly.rename(None),
        daily=y.rename(None),
        trend=fit.trend.rename(None),
        seasonal=annual.rename(None),
        remainder=remainder.rename(None),
        seasonal_by_period={WEEKLY_PERIOD: annual.rename(None)},
        imputed=imputed,
        warnings=warnings,
        day_of_week_share=shares,
    )


def _stl_input_weekly(
    y, imputed, params, warnings, annual_smoothing_days, robust
) -> Decomposition:
    """STL with period 52 on weekly input: ``_stl_weekly`` without the days."""
    _, STL = _require_statsmodels()
    fit = STL(y, period=WEEKLY_PERIOD, robust=robust).fit()
    smoothing_weeks = (
        max(1, round(annual_smoothing_days / 7)) if annual_smoothing_days > 1 else 1
    )
    if smoothing_weeks > 1 and smoothing_weeks % 2 == 0:
        smoothing_weeks += 1
    annual = _smooth(fit.seasonal, smoothing_weeks)
    remainder = fit.resid + (fit.seasonal - annual)
    params.update(
        weekly_period=WEEKLY_PERIOD,
        annual_smoothing_weeks=smoothing_weeks,
        statsmodels_version=_statsmodels_version(),
    )
    return Decomposition(
        method="stl",
        grain="week",
        params=params,
        observed=y.rename(None),
        trend=fit.trend.rename(None),
        seasonal=annual.rename(None),
        remainder=remainder.rename(None),
        seasonal_by_period={WEEKLY_PERIOD: annual.rename(None)},
        imputed=imputed,
        warnings=warnings,
    )


def _fourier(
    y, periods, imputed, params, warnings, fourier_terms, step_days: int = 1
) -> Decomposition:
    """Least squares on a trend, day-of-week effects and annual harmonics.

    ``step_days`` is 7 for weekly input: time is still counted in days, so the
    annual harmonics have their true 365.25-day cycle, while "one period
    earlier" is 52 rows (364 days) back, as the reference reads it.
    """
    t = (y.index - y.index[0]).days.to_numpy(dtype=float)
    columns: dict[str, np.ndarray] = {"const": np.ones(len(y)), "t": t / 365.25}
    weekly = 7 in periods
    if weekly:
        for dow in range(1, 7):
            columns[f"dow{dow}"] = (y.index.dayofweek == dow).astype(float)
    annual_periods = [p for p in periods if p != 7]
    for period in annual_periods:
        cycle = _annual_cycle(period, step_days)
        for k in range(1, fourier_terms + 1):
            angle = 2 * np.pi * k * t / cycle
            columns[f"sin{period}_{k}"] = np.sin(angle)
            columns[f"cos{period}_{k}"] = np.cos(angle)
    X = pd.DataFrame(columns, index=y.index)
    beta, *_ = np.linalg.lstsq(X.to_numpy(), y.to_numpy(), rcond=None)
    coef = pd.Series(beta, index=X.columns)

    # The seasonal as a forecast reads it, one period earlier, as a design
    # matrix: the lagged seasonal is Z @ beta. Day-of-week effects repeat
    # every 7 days, so their lag is themselves; annual harmonics are read at
    # t - period, and are unknown before the first full period.
    Z = np.zeros(X.shape)
    names = list(X.columns)
    if weekly:
        for dow in range(1, 7):
            Z[:, names.index(f"dow{dow}")] = (y.index.dayofweek == dow) - 1 / 7
    for period in annual_periods:
        cycle = _annual_cycle(period, step_days)
        back = t - period * step_days
        for k in range(1, fourier_terms + 1):
            angle = 2 * np.pi * k * back / cycle
            Z[:, names.index(f"sin{period}_{k}")] = np.where(
                back >= 0, np.sin(angle), np.nan
            )
            Z[:, names.index(f"cos{period}_{k}")] = np.where(
                back >= 0, np.cos(angle), np.nan
            )
    design = X.to_numpy()
    linear = {
        "X": design,
        "Z": Z,
        "xtx_inv": np.linalg.pinv(design.T @ design),
        "resid": y.to_numpy() - design @ beta,
    }

    components: dict[int, pd.Series] = {}
    level_shift = 0.0
    if weekly:
        effects = np.array([0.0] + [coef[f"dow{d}"] for d in range(1, 7)])
        level_shift = effects.mean()
        components[7] = pd.Series(
            effects[y.index.dayofweek] - level_shift, index=y.index
        )
    for period in annual_periods:
        names = [
            c for c in X.columns if c.startswith((f"sin{period}_", f"cos{period}_"))
        ]
        components[period] = X[names] @ coef[names]
    trend = coef["const"] + coef["t"] * X["t"] + level_shift
    seasonal = sum(components.values()) if components else pd.Series(0.0, index=y.index)
    remainder = y - trend - seasonal
    return Decomposition(
        method="fourier",
        grain="day" if step_days == 1 else "week",
        params=params,
        observed=y.rename(None),
        daily=y.rename(None) if step_days == 1 else pd.Series(dtype=float),
        trend=trend.rename(None),
        seasonal=seasonal.rename(None),
        remainder=remainder.rename(None),
        seasonal_by_period=components,
        imputed=imputed,
        warnings=warnings,
        linear=linear,
    )


def _annual_cycle(period: int, step_days: int) -> float:
    """A seasonal period's cycle in days: the annual one is 365.25 days."""
    if step_days == 1:
        return 365.25 if period == 365 else period
    return 365.25 if period == WEEKLY_PERIOD else period * step_days
