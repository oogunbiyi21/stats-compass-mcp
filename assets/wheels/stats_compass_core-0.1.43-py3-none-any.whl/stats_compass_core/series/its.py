"""Interrupted time series: did a window move a series, against what would have happened?

Architecture §7.5. For one window (a promotion) and one daily series:

- **Counterfactual.** The mean of the seasonally adjusted values over the
  ``baseline_days`` real days before the window, plus the seasonal pattern on
  each day of the window. Both adjustments read the seasonal one period
  earlier, the way a forecast made before the window would have read it. The
  decomposition never sees the window, the ``post_days`` after it (where
  pull-forward leaves a dip), or any ``other_windows``: those days are
  excluded from the fit.
- **Lift.** Observed total over the window minus the counterfactual total, in
  the series' units and in percent of the counterfactual.
- **Interval and test.** The same estimator applied at every past position
  where it can be tried (``Decomposition.expectation_errors``): the counterfactual
  and its reference are one function. The p-value ranks |lift| among the
  errors' sizes; the interval is the lift ± the ``level`` quantile of |error|,
  which is the same test inverted: it excludes zero exactly when
  p < 1 - level. Separate 5% and 95% quantiles rested each tail on one or
  two effectively independent windows (the windows overlap) and missed zero
  for 14% of inert promotions. Exact, so nothing is drawn.
- **Verdict.** §7.3 applied to the lift. The expected band is ± the
  ``band_level`` quantile of |error|, where ``band_level`` is the normal
  coverage of ``±seasonal_band_z`` (0.954 at 2): the same basis as the
  interval and the test, at the band's level. With ``noise_band="prior_window"`` the noise band is the
  lift estimated at ``prior_window`` ± ``noise_band_z`` × √2 × the errors'
  spread: two estimates by the same function, each with the reference's
  variance. It needs a seasonal period before the prior window, so with two
  years of history it is unavailable. ``"none"`` (the default until the
  calibration is decided) skips it.

The interval is at ``level`` and the band at ``band_level``; a 90% interval can
exclude zero while the lift is still ``expected``. Both levels are in
``params`` so a caller does not print one beside the other as a contradiction.

- **Series, for a chart (optional).** With ``series_days_before`` or
  ``series_days_after``, each day around the window with its observed value
  and the counterfactual: the same level, plus the seasonal read one period
  earlier on that day. Over the window's days with data, observed minus
  expected sums to the lift exactly, so the gap between the lines is the lift.
  ``low`` and ``high`` are a range for one day's value: the ``level`` ranked
  |error| of this estimator applied to single days, measured like the lift's
  reference. It is not the lift's interval, which is for the window's total.

**Weekly input** (``freq="W"``): the same estimator on weeks. The window is
every week it touches (``weeks_overlapping``), and every ``*_days`` argument
must be whole weeks: a 28-day baseline is four weeks, 21 post days are three.
``series`` then holds one row per week, labelled as the input is.

Not measured: pull-forward. Customers who would have bought after the window
but bought inside it inflate the lift, and the dip they leave is excluded from
the fit rather than netted off.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, Literal, Sequence

import numpy as np
import pandas as pd
from scipy import stats

from stats_compass_core.results import ToolWarning
from stats_compass_core.series._common import (
    Freq,
    Insufficient,
    WeekLabel,
    weekly_freq,
    weeks_overlapping,
)
from stats_compass_core.series.decompose import Decomposition, Method, decompose

Kind = Literal["count", "money"]
NoiseBand = Literal["prior_window", "none"]
Window = tuple[date, date]

# A baseline needs this share of its days to hold real data.
MIN_BASELINE_SHARE = 0.8
MIN_REFERENCE_WINDOWS = 20


@dataclass(frozen=True)
class CounterfactualDay:
    """One day around a window: what happened, and what was expected without it.

    ``actual`` is None on a day with no data. ``low`` and ``high`` bound a
    single day's value at the lift's ``level``; see the module notes.
    """

    date: date
    actual: float | None
    expected: float
    low: float
    high: float
    in_window: bool


@dataclass(frozen=True)
class LiftFacts:
    """A window's lift over its counterfactual, with an interval and a verdict.

    ``estimate_pct`` and ``interval_pct`` are None when the counterfactual
    total is not positive: a percentage of zero or less means nothing.
    """

    estimate_abs: float
    interval_abs: tuple[float, float]
    estimate_pct: float | None
    interval_pct: tuple[float, float] | None
    observed_total: float
    counterfactual_total: float
    verdict: Literal["expected", "noise", "real change"]
    decided_by: Literal["expected_band", "noise_band", "test"]
    p_value: float
    n_reference: int
    prior_lift_pct: float | None
    expected_range_pct: tuple[float, float] | None
    noise_range_pct: tuple[float, float] | None
    method: str
    params: dict[str, Any]
    warnings: list[ToolWarning]
    series: tuple[CounterfactualDay, ...] | None = None


def its_lift(
    values: pd.Series,
    window: Window,
    *,
    kind: Kind,
    method: Method = "mstl",
    periods: Sequence[int] = (7, 365),
    baseline_days: int = 28,
    baseline_lookback_days: int = 84,
    post_days: int = 21,
    prior_window: Window | None = None,
    other_windows: Sequence[Window] = (),
    noise_band: NoiseBand = "none",
    level: float = 0.9,
    seasonal_band_z: float = 2.0,
    noise_band_z: float = 3.0,
    real_change_alpha: float = 0.05,
    min_baseline_share: float = 0.8,
    min_reference: int = 20,
    series_days_before: int | None = None,
    series_days_after: int | None = None,
    freq: Freq = "D",
    week_label: WeekLabel = "end",
    **decompose_options: Any,
) -> LiftFacts | Insufficient:
    """Estimate one window's lift on one daily series.

    Args:
        values: The full daily history, the window included. NaN = no data.
        window: First and last day of the window.
        kind: ``"money"`` or ``"count"``. Both use the empirical test; the kind
            is recorded so a caller can see what was assumed.
        method, periods: The decomposition (see ``decompose``).
        baseline_days: Real days before the window whose seasonally adjusted
            mean is the counterfactual level.
        baseline_lookback_days: How far back the baseline may reach past
            excluded or missing days to find them. Promotions a month apart
            would otherwise leave each other no baseline.
        post_days: Days after the window excluded from the fit and from the
            reference, where pull-forward leaves a dip.
        prior_window: The comparable window one cycle earlier; its lift
            centres the noise band when ``noise_band="prior_window"``.
        other_windows: Other promotions, excluded the same way.
        noise_band: ``"none"`` or ``"prior_window"``; see the module notes.
        level: Interval level.
        seasonal_band_z, noise_band_z, real_change_alpha: The calibration.
        min_baseline_share: Share of ``baseline_days`` that must hold real
            data.
        min_reference: Fewest past positions to measure the error against.
        series_days_before, series_days_after: Ask for ``series``: each day
            from this many days before the window to this many after, clipped
            to the history. Both None (the default) leaves ``series`` None.
        freq, week_label: ``"W"`` for weekly input, and which day of its week
            each date names; see the module notes and ``decompose``.
        **decompose_options: Passed to ``decompose`` (``max_gap_days``,
            ``annual_smoothing_days``, ``fourier_terms``, ``robust``).

    Returns:
        ``LiftFacts``, or ``Insufficient``: the decomposition's own reasons,
        ``BASELINE_TOO_SHORT``, ``TOO_FEW_POINTS`` (under half the window has
        data), ``NO_SEASONAL_BEFORE`` (no seasonal period before the window
        to read), ``TOO_SHORT`` (too few past positions to measure the error).
    """
    if kind not in ("count", "money"):
        raise ValueError(f"unknown kind {kind!r}")
    if noise_band not in ("prior_window", "none"):
        raise ValueError(f"unknown noise_band {noise_band!r}")
    want_series = series_days_before is not None or series_days_after is not None
    days_before, days_after = series_days_before or 0, series_days_after or 0
    if days_before < 0 or days_after < 0:
        raise ValueError("series days cannot be negative")
    start, end = pd.Timestamp(window[0]), pd.Timestamp(window[1])
    if end < start:
        raise ValueError("window ends before it starts")
    length = (end - start).days + 1
    weekly = freq == "W"
    if weekly:
        for name, days in (
            ("baseline_days", baseline_days),
            ("baseline_lookback_days", baseline_lookback_days),
            ("post_days", post_days),
            ("series_days_before", days_before),
            ("series_days_after", days_after),
        ):
            if days % 7:
                raise ValueError(
                    f"weekly input counts whole weeks: {name} must be a multiple "
                    f"of 7, not {days}"
                )

    def tail(w: Window) -> tuple[date, date]:
        return (w[0], w[1] + timedelta(days=post_days))

    exclusions = [tail(window), *[tail(w) for w in other_windows]]
    dec = decompose(
        values,
        method=method,
        periods=periods,
        exclude=exclusions,
        trend_window_days=baseline_days,
        **({"freq": "W", "week_label": week_label} if weekly else {}),
        **decompose_options,
    )
    if isinstance(dec, Insufficient):
        return dec

    observed_series = values.copy()
    observed_series.index = pd.DatetimeIndex(observed_series.index).normalize()
    unit = "weeks" if weekly else "days"
    step = pd.Timedelta(days=7 if weekly else 1)
    if weekly:
        # The window's weeks on the input's own weekly grid, and the counts
        # of days read in weeks from here on.
        labels = _window_weeks(observed_series.index, start, end, week_label)
        length = len(labels)
        start, end = labels[0], labels[-1]
        observed = observed_series.reindex(labels).astype(float)
        steps = {
            "baseline": baseline_days // 7,
            "lookback": baseline_lookback_days // 7,
            "post": post_days // 7,
            "before": days_before // 7,
            "after": days_after // 7,
        }
    else:
        observed = observed_series.reindex(pd.date_range(start, end)).astype(float)
        steps = {
            "baseline": baseline_days,
            "lookback": baseline_lookback_days,
            "post": post_days,
            "before": days_before,
            "after": days_after,
        }
    present = observed.notna()
    if int(present.sum()) * 2 < length:
        return Insufficient(
            needs=(length + 1) // 2,
            has=int(present.sum()),
            unit=unit,
            reason="TOO_FEW_POINTS",
        )

    def attempt(d: Decomposition):
        """The estimate and its reference from one decomposition, or why not."""
        est = _estimate(
            d,
            observed_series,
            start,
            present,
            steps["baseline"],
            steps["lookback"],
            min_baseline_share,
            step=step,
            unit=unit,
        )
        if isinstance(est, Insufficient):
            return est, None
        errs = d.expectation_errors(length, delete_after_days=steps["post"])
        if len(errs) < min_reference:
            short = Insufficient(
                needs=min_reference, has=len(errs), unit=unit, reason="TOO_SHORT"
            )
            return short, None
        return est, errs

    estimate, errors = attempt(dec)
    annual_fallback = False
    if isinstance(estimate, Insufficient) and estimate.reason in (
        "NO_SEASONAL_BEFORE",
        "BASELINE_TOO_SHORT",
        "TOO_SHORT",
    ):
        # The annual pattern needs a year before the window to read, and uses
        # up a year of the reference; the weekly pattern alone may not.
        fallback = dec.without_annual()
        if fallback is not None:
            retried, retried_errors = attempt(fallback)
            if not isinstance(retried, Insufficient):
                dec, estimate, errors = fallback, retried, retried_errors
                annual_fallback = True
    if isinstance(estimate, Insufficient):
        return estimate
    observed_total, counterfactual_total, cf_level, baseline_info = estimate
    lift_abs = observed_total - counterfactual_total
    lift_pct = (
        100 * lift_abs / counterfactual_total if counterfactual_total > 0 else None
    )

    err_abs = errors["error"].to_numpy()
    positive = errors["expected"].to_numpy() > 0
    err_pct = 100 * err_abs[positive] / errors["expected"].to_numpy()[positive]

    interval_abs = _interval(lift_abs, err_abs, level)
    interval_pct = _interval(lift_pct, err_pct, level) if lift_pct is not None else None

    # Judge on the percent scale when there is one: it does not drift with the
    # store's growth the way absolute errors do.
    judged, reference = (
        (lift_pct, err_pct) if lift_pct is not None else (lift_abs, err_abs)
    )
    p_value = (1 + int(np.sum(np.abs(reference) >= abs(judged)))) / (len(reference) + 1)
    band_level = float(2 * stats.norm.cdf(seasonal_band_z) - 1)
    band_half = _ranked_half_width(reference, band_level)
    expected_range = (-band_half, band_half)
    spread = float(np.std(reference, ddof=1))

    prior_lift_pct: float | None = None
    prior_info: dict[str, Any] = {}
    if prior_window is not None:
        prior = _prior_lift(
            dec,
            observed_series,
            prior_window,
            steps["baseline"],
            steps["lookback"],
            min_baseline_share,
            step=step,
            week_label=week_label if weekly else None,
        )
        if isinstance(prior, str):
            prior_info = {"prior_unavailable": prior}
        else:
            prior_lift_pct, populated = prior
            prior_info = {"prior_window_populated_share": populated}
    noise_range: tuple[float, float] | None = None
    if (
        noise_band == "prior_window"
        and prior_lift_pct is not None
        and lift_pct is not None
    ):
        half = noise_band_z * math.sqrt(2) * spread
        noise_range = (prior_lift_pct - half, prior_lift_pct + half)

    if expected_range[0] <= judged <= expected_range[1]:
        outcome, decided_by = "expected", "expected_band"
    elif noise_range is not None and noise_range[0] <= judged <= noise_range[1]:
        outcome, decided_by = "noise", "noise_band"
    elif p_value < real_change_alpha:
        outcome, decided_by = "real change", "test"
    else:
        outcome, decided_by = "noise", "test"

    params: dict[str, Any] = {
        "kind": kind,
        "window": [str(window[0]), str(window[1])],
        "baseline_days": baseline_days,
        "baseline_lookback_days": baseline_lookback_days,
        "min_baseline_share": min_baseline_share,
        "min_reference": min_reference,
        "post_days": post_days,
        "prior_window": None
        if prior_window is None
        else [str(prior_window[0]), str(prior_window[1])],
        "other_windows": [[str(a), str(b)] for a, b in other_windows],
        "noise_band": noise_band,
        "level": level,
        "interval_level": level,
        "band_level": band_level,
        "band_basis": "abs_error_quantile",
        "interval_basis": "abs_error_quantile",
        "seasonal_band_z": seasonal_band_z,
        "noise_band_z": noise_band_z,
        "real_change_alpha": real_change_alpha,
        "exclude": [
            [pd.Timestamp(a).date().isoformat(), pd.Timestamp(b).date().isoformat()]
            for a, b in exclusions
        ],
        "n_window_days_with_data": int(present.sum()),
        "judged_on": "percent" if lift_pct is not None else "absolute",
        "annual_fallback": annual_fallback,
        "reference": errors.attrs["reference"],
        "decomposition": dec.params,
        **baseline_info,
        **prior_info,
    }
    if weekly:
        params["n_window_weeks_with_data"] = params.pop("n_window_days_with_data")
        params.update(
            input_freq="W",
            week_label=week_label,
            window_weeks=[day.date().isoformat() for day in labels],
        )
    series: tuple[CounterfactualDay, ...] | None = None
    if want_series:
        day_errors = dec.expectation_errors(1, delete_after_days=steps["post"])
        half = _ranked_half_width(day_errors["error"].to_numpy(), level)
        series = _series(
            dec,
            observed_series,
            start,
            end,
            cf_level,
            half,
            steps["before"],
            steps["after"],
            step=step,
        )
        params.update(
            series_days_before=days_before,
            series_days_after=days_after,
            series_band_half_width=half,
            series_band_level=level,
            series_band_basis="single_day_abs_error_quantile",
            series_band_reference=day_errors.attrs["reference"],
            series_band_n_reference=int(len(day_errors)),
        )
    return LiftFacts(
        estimate_abs=float(lift_abs),
        interval_abs=interval_abs,
        estimate_pct=None if lift_pct is None else float(lift_pct),
        interval_pct=interval_pct,
        observed_total=float(observed_total),
        counterfactual_total=float(counterfactual_total),
        verdict=outcome,
        decided_by=decided_by,
        p_value=float(p_value),
        n_reference=int(len(reference)),
        prior_lift_pct=prior_lift_pct,
        expected_range_pct=expected_range if lift_pct is not None else None,
        noise_range_pct=noise_range,
        method=f"{dec.method}+its_empirical_windows",
        params=params,
        warnings=list(dec.warnings),
        series=series,
    )


def _series(
    dec: Decomposition,
    values: pd.Series,
    start: pd.Timestamp,
    end: pd.Timestamp,
    level: float,
    half: float,
    days_before: int,
    days_after: int,
    step: pd.Timedelta = pd.Timedelta(days=1),
) -> tuple[CounterfactualDay, ...]:
    """Each day around the window, observed against the counterfactual.

    Clipped to the history, and to the days the seasonal can be read one
    period back on: before that there is no counterfactual to draw. For
    weekly input each row is a week (``step`` 7 days, counts in weeks).
    """
    lagged = dec._lagged_seasonal_daily()
    first = max(start - step * days_before, lagged.index[0])
    last = min(end + step * days_after, values.index.max(), lagged.index[-1])
    days = pd.date_range(first, last, freq=step)
    seasonal = lagged.reindex(days)
    observed = values.reindex(days).astype(float)
    rows = []
    for day, s, obs in zip(days, seasonal.to_numpy(), observed.to_numpy()):
        if not np.isfinite(s):
            continue
        expected = level + float(s)
        rows.append(
            CounterfactualDay(
                date=day.date(),
                actual=float(obs) if np.isfinite(obs) else None,
                expected=expected,
                low=expected - half,
                high=expected + half,
                in_window=bool(start <= day <= end),
            )
        )
    return tuple(rows)


def _estimate(
    dec: Decomposition,
    values: pd.Series,
    start: pd.Timestamp,
    present: pd.Series,
    baseline_days: int,
    lookback_days: int,
    min_share: float = MIN_BASELINE_SHARE,
    step: pd.Timedelta = pd.Timedelta(days=1),
    unit: str = "days",
) -> tuple[float, float, float, dict[str, Any]] | Insufficient:
    """Observed and counterfactual totals over the window's days with data, and the level.

    The estimator ``expectation_errors`` measures: seasonal read one period
    earlier, level from the adjusted baseline. The baseline walks back past
    excluded, imputed and missing days, up to ``lookback_days``, until it has
    ``baseline_days`` real ones. For weekly input every count is in weeks and
    ``step`` is 7 days.
    """
    lagged = dec._lagged_seasonal_daily()
    adjusted = dec.base - lagged
    filled = set(dec.imputed) | set(dec.excluded)
    needed = math.ceil(min_share * baseline_days)
    chosen: list[pd.Timestamp] = []
    for back in range(1, lookback_days + 1):
        day = start - step * back
        if day < adjusted.index[0]:
            break
        if day.date() in filled or not np.isfinite(adjusted.get(day, np.nan)):
            continue
        chosen.append(day)
        if len(chosen) == baseline_days:
            break
    if len(chosen) < needed:
        return Insufficient(
            needs=needed, has=len(chosen), unit=unit, reason="BASELINE_TOO_SHORT"
        )
    days = present.index[present.to_numpy()]
    seasonal = lagged.reindex(days)
    if not np.isfinite(seasonal.to_numpy()).all():
        return Insufficient(
            needs=None, has=None, unit=unit, reason="NO_SEASONAL_BEFORE"
        )
    level = float(adjusted.loc[chosen].mean())
    counterfactual = level * len(days) + float(seasonal.sum())
    observed = float(values.reindex(days).sum())
    if unit == "weeks":
        info = {
            "baseline_real_weeks": len(chosen),
            "baseline_first_week": min(chosen).date().isoformat(),
        }
    else:
        info = {
            "baseline_real_days": len(chosen),
            "baseline_first_day": min(chosen).date().isoformat(),
        }
    return observed, counterfactual, level, info


def _prior_lift(
    dec: Decomposition,
    values: pd.Series,
    prior: Window,
    baseline_days: int,
    lookback_days: int,
    min_share: float = MIN_BASELINE_SHARE,
    step: pd.Timedelta = pd.Timedelta(days=1),
    week_label: WeekLabel | None = None,
) -> tuple[float, float] | str:
    """The same estimate at the comparable prior window, or why there is none.

    ``week_label`` is set for weekly input: the prior window is then the weeks
    it touches.
    """
    start, end = pd.Timestamp(prior[0]), pd.Timestamp(prior[1])
    if week_label is not None:
        labels = _window_weeks(values.index, start, end, week_label)
        start = labels[0]
        observed = values.reindex(labels).astype(float)
    else:
        observed = values.reindex(pd.date_range(start, end)).astype(float)
    present = observed.notna()
    if not present.any():
        return "NO_DATA_IN_PRIOR"
    estimate = _estimate(
        dec,
        values,
        start,
        present,
        baseline_days,
        lookback_days,
        min_share,
        step=step,
        unit="days" if week_label is None else "weeks",
    )
    if isinstance(estimate, Insufficient):
        return (
            "NO_SEASONAL_BEFORE_PRIOR"
            if estimate.reason == "NO_SEASONAL_BEFORE"
            or estimate.reason == "BASELINE_TOO_SHORT"
            and not np.isfinite(dec._lagged_seasonal_daily().get(start, np.nan))
            else estimate.reason
        )
    observed_total, counterfactual_total, _, _ = estimate
    if counterfactual_total <= 0:
        return "NONPOSITIVE_COUNTERFACTUAL"
    lift = 100 * (observed_total - counterfactual_total) / counterfactual_total
    return float(lift), float(present.mean())


def _window_weeks(
    index: pd.DatetimeIndex, start: pd.Timestamp, end: pd.Timestamp, week_label: WeekLabel
) -> pd.DatetimeIndex:
    """The weeks a window touches, on the input's weekly grid, past its ends too.

    The grid runs a week beyond the window on either side, so a window after
    the last row (no data yet) still names its weeks, and is then found to
    have too few with data.
    """
    freq = weekly_freq(index)
    first = min(index.min(), start - pd.Timedelta(days=7))
    last = max(index.max(), end + pd.Timedelta(days=7))
    grid = pd.date_range(first, last, freq=freq)
    return weeks_overlapping(grid, start, end, week_label)


def _ranked_half_width(errors: np.ndarray, level: float) -> float:
    """The |error| the p-value's ranking puts at ``1 - level``.

    p = (1 + #{|e| >= |x|}) / (N + 1) < 1 - level exactly when |x| exceeds
    the j-th largest |e|, j = ceil((1 - level)(N + 1) - 1). Taking the
    half-width from that order statistic, not an interpolated quantile, makes
    "the interval excludes zero" and "p < 1 - level" the same statement.
    With too few errors to reach the level, it is the largest |error|.
    """
    ordered = np.sort(np.abs(errors))[::-1]
    j = math.ceil((1 - level) * (len(ordered) + 1) - 1)
    return float(ordered[min(max(j, 1), len(ordered)) - 1])


def _interval(estimate: float, errors: np.ndarray, level: float) -> tuple[float, float]:
    """Estimate ± the ranked half-width: the test, inverted."""
    half = _ranked_half_width(errors, level)
    return float(estimate - half), float(estimate + half)
